package com.icedragon.launcher

import android.graphics.drawable.Drawable

data class AppInfo(
    val label: String,
    val packageName: String,
    val defaultIcon: Drawable,
    var customIconPath: String? = null
)
