package com.icedragon.launcher

import android.content.Context
import android.graphics.BitmapFactory
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import java.io.File

class AppAdapter(
    private val context: Context,
    private val apps: MutableList<AppInfo>
) : BaseAdapter() {

    override fun getCount(): Int = apps.size
    override fun getItem(position: Int): AppInfo = apps[position]
    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view = convertView ?: LayoutInflater.from(context)
            .inflate(R.layout.item_app, parent, false)

        val app = apps[position]
        val iconView = view.findViewById<ImageView>(R.id.appIcon)
        val labelView = view.findViewById<TextView>(R.id.appLabel)

        val customPath = app.customIconPath
        if (customPath != null && File(customPath).exists()) {
            val bitmap = BitmapFactory.decodeFile(customPath)
            if (bitmap != null) {
                iconView.setImageBitmap(bitmap)
            } else {
                iconView.setImageDrawable(app.defaultIcon)
            }
        } else {
            iconView.setImageDrawable(app.defaultIcon)
        }

        labelView.text = app.label
        return view
    }
}
