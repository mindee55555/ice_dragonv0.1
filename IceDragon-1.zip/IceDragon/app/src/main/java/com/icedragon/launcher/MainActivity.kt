package com.icedragon.launcher

import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.widget.GridView
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var apps: MutableList<AppInfo>
    private lateinit var adapter: AppAdapter
    private lateinit var wallpaperImage: ImageView
    private lateinit var overlayImage: ImageView

    // نتذكر أي طلب اختيار صورة كان جارياً: أيقونة تطبيق معيّن، أو خلفية، أو طبقة متحركة
    private var pendingIconTargetPackage: String? = null
    private var pendingRequest: Int = 0

    companion object {
        const val REQ_ICON = 1
        const val REQ_WALLPAPER = 2
        const val REQ_OVERLAY = 3
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wallpaperImage = findViewById(R.id.wallpaperImage)
        overlayImage = findViewById(R.id.overlayImage)

        apps = loadLaunchableApps()
        adapter = AppAdapter(this, apps)

        val grid = findViewById<GridView>(R.id.appGrid)
        grid.adapter = adapter

        grid.setOnItemClickListener { _, _, position, _ ->
            launchApp(apps[position].packageName)
        }
        grid.setOnItemLongClickListener { _, _, position, _ ->
            showIconOptions(apps[position])
            true
        }

        findViewById<android.widget.Button>(R.id.btnPickWallpaper).setOnClickListener {
            pendingRequest = REQ_WALLPAPER
            openImagePicker(REQ_WALLPAPER)
        }
        findViewById<android.widget.Button>(R.id.btnPickOverlay).setOnClickListener {
            pendingRequest = REQ_OVERLAY
            openImagePicker(REQ_OVERLAY)
        }

        findViewById<SeekBar>(R.id.overlayAlphaSeek).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    overlayImage.alpha = progress / 100f
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            }
        )

        loadSavedWallpaperAndOverlay()
    }

    override fun onResume() {
        super.onResume()
        // إعادة تحميل الأيقونات المخصصة في حال تغيّرت
        val icons = iconsDir()
        for (app in apps) {
            val f = File(icons, "${app.packageName}.png")
            app.customIconPath = if (f.exists()) f.absolutePath else null
        }
        adapter.notifyDataSetChanged()
    }

    // ---------- تحميل قائمة التطبيقات الحقيقية من النظام ----------
    private fun loadLaunchableApps(): MutableList<AppInfo> {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolved = pm.queryIntentActivities(intent, 0)
        val icons = iconsDir()

        val list = resolved.map { ri ->
            val pkg = ri.activityInfo.packageName
            val customFile = File(icons, "$pkg.png")
            AppInfo(
                label = ri.loadLabel(pm).toString(),
                packageName = pkg,
                defaultIcon = ri.loadIcon(pm),
                customIconPath = if (customFile.exists()) customFile.absolutePath else null
            )
        }.sortedBy { it.label.lowercase() }.toMutableList()

        return list
    }

    private fun launchApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "تعذر فتح هذا التطبيق", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- تغيير أيقونة تطبيق معيّن ----------
    private fun showIconOptions(app: AppInfo) {
        val options = arrayOf(
            getString(R.string.pick_custom_icon),
            getString(R.string.reset_icon)
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        pendingIconTargetPackage = app.packageName
                        openImagePicker(REQ_ICON)
                    }
                    1 -> {
                        val f = File(iconsDir(), "${app.packageName}.png")
                        if (f.exists()) f.delete()
                        app.customIconPath = null
                        adapter.notifyDataSetChanged()
                    }
                }
            }
            .show()
    }

    // ---------- منتقي الصور من المعرض ----------
    private fun openImagePicker(requestCode: Int) {
        pendingRequest = requestCode
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "image/*"
        }
        startActivityForResult(Intent.createChooser(intent, null), requestCode)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri: Uri = data?.data ?: return

        when (requestCode) {
            REQ_ICON -> {
                val pkg = pendingIconTargetPackage ?: return
                val target = File(iconsDir(), "$pkg.png")
                if (copyUriToFile(uri, target)) {
                    apps.find { it.packageName == pkg }?.customIconPath = target.absolutePath
                    adapter.notifyDataSetChanged()
                }
                pendingIconTargetPackage = null
            }
            REQ_WALLPAPER -> {
                val target = File(filesDir, "wallpaper.png")
                if (copyUriToFile(uri, target)) {
                    setWallpaperFromFile(target)
                }
            }
            REQ_OVERLAY -> {
                val target = File(filesDir, "overlay.png")
                if (copyUriToFile(uri, target)) {
                    setOverlayFromFile(target)
                }
            }
        }
    }

    // ---------- تحميل خلفية وطبقة محفوظتين مسبقاً عند فتح التطبيق ----------
    private fun loadSavedWallpaperAndOverlay() {
        val wp = File(filesDir, "wallpaper.png")
        if (wp.exists()) setWallpaperFromFile(wp)

        val ov = File(filesDir, "overlay.png")
        if (ov.exists()) setOverlayFromFile(ov)
    }

    private fun setWallpaperFromFile(file: File) {
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return
        wallpaperImage.setImageBitmap(bmp)
    }

    private fun setOverlayFromFile(file: File) {
        val bmp = BitmapFactory.decodeFile(file.absolutePath) ?: return
        overlayImage.setImageBitmap(bmp)
        overlayImage.visibility = ImageView.VISIBLE
    }

    // ---------- أدوات مساعدة للتخزين الداخلي ----------
    private fun iconsDir(): File {
        val dir = File(filesDir, "icons")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    private fun copyUriToFile(uri: Uri, target: File): Boolean {
        return try {
            contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output)
                }
            }
            true
        } catch (e: Exception) {
            Toast.makeText(this, "تعذر حفظ الصورة", Toast.LENGTH_SHORT).show()
            false
        }
    }
}
